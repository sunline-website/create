import * as Icns from '@fiahfy/icns';
import {Buffer} from 'buffer';

export {
  Icns,
  Buffer
};
