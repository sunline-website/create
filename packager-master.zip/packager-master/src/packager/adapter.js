export let Adapter = null;

export const setAdapter = (newAdapter) => {
  Adapter = newAdapter;
};
