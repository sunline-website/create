<script>
  export let value;
</script>

<input type="color" bind:value />
